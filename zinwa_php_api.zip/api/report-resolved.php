<?php
include("connection.php");
if(isset($_GET["fault_id"])){        
	$fault_id = mysqli_real_escape_string($conn,$_GET["fault_id"]);
	$date=date('Y-m-d H:i:s');
	$statement="UPDATE tblfaults SET fldstatus='Resolved' WHERE fldfault_id='$fault_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response=array("response"=>"success");
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);
?>
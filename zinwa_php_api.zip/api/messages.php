<?php
include("connection.php");
$messages=array();
$array=array();
$statement="SELECT * FROM tblmessages";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));

while($record=mysqli_fetch_assoc($query)){
    $temp=array();
    $temp["messageId"]=$record["fldmessage_id"];
    $temp["fromUserId"]=$record["fldfrom"];          
    $temp["time"]=$record["fldtimestamp"];
    $temp["message"]=$record["fldmessage"];
    $temp["type"]=$record["fldtype"];
    $temp["status"]="success";

    $statement="SELECT * FROM tblusers WHERE flduser_id='$record[fldfrom]'";
    $user_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
    while($user=mysqli_fetch_assoc($user_query)){
        if($user["flduser_id"]==$record["fldfrom"]){
            $temp["fromUserName"]=$user['fldforename'].' '.$user['fldsurname'];
        }
    }

    $statement="SELECT * FROM tblusers WHERE flduser_id='$record[fldfrom]'";
    $user_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
    while($user=mysqli_fetch_assoc($user_query)){
        if($user["flduser_id"]==$record["fldfrom"]){
            $temp["fromUserName"]=$user['fldforename'].' '.$user['fldsurname'];
        }
        $temp["access_level"]=$user['fldaccess_level'];
    }
    $array[]=$temp;
}
$messages["array"]=$array;
echo json_encode($messages);
?>
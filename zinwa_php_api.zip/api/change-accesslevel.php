<?php
include("connection.php");
if(isset($_GET["user_id"]) && isset($_GET["access"])){        
	$user_id = mysqli_real_escape_string($conn,$_GET["user_id"]);
	$accesslevel = mysqli_real_escape_string($conn,$_GET["access"]);
	$statement="UPDATE tblusers SET fldaccess_level='$accesslevel' WHERE flduser_id='$user_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response['response']='success';
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

?>
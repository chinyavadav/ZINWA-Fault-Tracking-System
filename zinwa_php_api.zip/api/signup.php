<?php
include("connection.php");
header('Content-Type: application/json');
if($_SERVER["REQUEST_METHOD"]=="POST"){		
	$postdata = file_get_contents('php://input');
	if (isset($postdata)) {
		$request = json_decode($postdata);
		$phoneno=mysqli_real_escape_string($conn,$request->phoneno);
		$forename=mysqli_real_escape_string($conn,$request->forename);
		$surname=mysqli_real_escape_string($conn,$request->surname);
		$status='Active';	        
		$password=mysqli_real_escape_string($conn,$request->password);

		$statement="INSERT INTO tblusers(fldphone_no,fldforename,fldsurname,fldaccess_level,fldpassword,fldstatus) VALUES('$phoneno','$forename','$surname','Standard',md5('$password'),'$status')";
		$query=mysqli_query($conn,$statement) or die(error());
		$response=array('response'=>'success');
	}else {
		$response=array('response'=>'failed');
	}
	echo json_encode($response);	    
}

function error(){
	$response=array('response'=>'failed');
	echo json_encode($response);	
}
?>
<?php
include("connection.php");
$engineers=array();
$statement="SELECT * FROM tblusers WHERE fldaccess_level='Engineer' and fldstatus='Active'";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
    $engineers[]=$record;
}
echo json_encode($engineers);   
?>
<?php
include("connection.php");
$faults=array();
if(isset($_GET["mode"])){
	$mode=mysqli_real_escape_string($conn,$_GET["mode"]);
	$statement="SELECT * FROM tblfaults WHERE fldstatus='$mode'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$faults[]=$record;
	}
}
echo json_encode($faults);   
?>
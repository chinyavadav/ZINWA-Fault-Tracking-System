<?php
include("connection.php");
$users=array();
$statement="SELECT * FROM tblusers ORDER BY fldaccess_level DESC";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
    $users[]=$record;
}
echo json_encode($users);   
?>
<?php
include("connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
	$postdata = file_get_contents("php://input");
	if (isset($postdata)) {
		$request = json_decode($postdata);
		$from = mysqli_real_escape_string($conn,$request->from);
		$message =mysqli_real_escape_string($conn,$request->message);
		$type =mysqli_real_escape_string($conn,$request->type);
		$timestamp=date('H:i:s');
		$statement="INSERT INTO tblmessages VALUES('','$from','$message','$type','$timestamp')";
		$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
		$response=array("response"=>"success");
	}else{
		$response=array("response"=>"failed");
	}
	echo json_encode($response);
}

?>
<?php
include("connection.php");
$faults=array();
if(isset($_GET["user_id"]) && isset($_GET["mode"])){
	$user_id=mysqli_real_escape_string($conn,$_GET["user_id"]);
	$mode=mysqli_real_escape_string($conn,$_GET["mode"]);
	$statement="SELECT * FROM tblengineer_allocations JOIN tblfaults ON tblengineer_allocations.fldfault_id=tblfaults.fldfault_id WHERE tblengineer_allocations.flduser_id='$user_id' and tblfaults.fldstatus='$mode'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$faults[]=$record;
	}
}
echo json_encode($faults);   
?>
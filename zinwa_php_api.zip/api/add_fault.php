<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $user_id=mysqli_real_escape_string($conn,$request->user_id);
	        $type=mysqli_real_escape_string($conn,$request->type);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $latitude=mysqli_real_escape_string($conn,$request->latitude);
	        $longitude=mysqli_real_escape_string($conn,$request->longitude);
	        $date=date('Y-m-d H:i:s');
	        $picture=$request->picture;

	        $statement="INSERT INTO tblfaults(flduser_id,fldfault_type,fldlatitude,fldlongitude,fldtimestamp,fldstatus,fldcomment,fldpicture) VALUES('$user_id','$type','$latitude','$longitude','$date','Pending','$description','$picture')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>
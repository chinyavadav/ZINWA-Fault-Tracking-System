<?php
include("connection.php");
if(isset($_GET["user_id"]) && isset($_GET["fault_id"])){        
	$user_id = mysqli_real_escape_string($conn,$_GET["user_id"]);
	$fault_id = mysqli_real_escape_string($conn,$_GET["fault_id"]);
	$date=date('Y-m-d H:i:s');
	$statement="INSERT INTO tblengineer_allocations VALUES('$fault_id','$user_id','$date')";
	$statementUpdate="UPDATE tblengineer_allocations SET flduser_id='$user_id',fldtimestamp='$date' WHERE fldfault_id='$fault_id'";
	$query=mysqli_query($conn,$statement) or die(update($conn,$statementUpdate,$fault_id));
	if(updateFault($conn,$fault_id)){
		$response['response']='success';
	}else{
		$response['response']='failed';
	}
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

function update($conn,$statement,$fault_id){
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	if(updateFault($conn,$fault_id)){
		$response=Array('response'=>'success');
	}else{
		$response=Array('response'=>'failed');
	}
	echo json_encode($response);
}

function updateFault($conn,$fault_id){
	$statement="UPDATE tblfaults SET fldstatus='Allocated' WHERE fldfault_id='$fault_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	return true;
}
?>